import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../main.dart';
import 'FormCard.Dart';
class SignUp extends StatelessWidget {


  Widget horizontalLine() =>
      Padding(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          width: ScreenUtil.getInstance().setWidth(140),
          height: 1.0,
          color: Colors.purple.withOpacity(.2),
        ),
      );

  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil.getInstance()
      ..init(context);
    ScreenUtil.instance =
        ScreenUtil(width: 750, height: 1334, allowFontScaling: true);
    return new Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomPadding: true,
        body: Stack(

            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 20.0),
                    child: Image.asset("assets/image.png",),


                  ),
                  Expanded(
                    child: Container(


                    ),

                  ),
                  //Image.asset("assets/image.png"),


                ],


              ),
              SingleChildScrollView(
                  child: Padding(
                      padding: EdgeInsets.only(left:28.0,right: 28.0,top :60.0),
                      child:Column
                        (
                          children: <Widget>[
                            Row(

                              children: <Widget>[Image.asset("", width: ScreenUtil.getInstance().setWidth(110))],
                            ),
                            SizedBox(
                              height: ScreenUtil.getInstance().setHeight(180),

                            ),
                            Container(
                              width: double.infinity,
                              height: 440,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      offset: Offset(0.0,15.0),
                                      blurRadius: 15.0,

                                    ),

                                    BoxShadow(
                                        color: Colors.black12,
                                        offset: Offset(0.0,15.0),
                                        blurRadius: 15.0),

                                  ]


                              ),
                              child: Padding(
                                padding: EdgeInsets.only(left:16.0,right: 16.0,top: 16.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Text("S'inscrire" , style: TextStyle(
                                        fontSize: ScreenUtil.getInstance().setSp(45),
                                        fontFamily: "Poppins-Bold",
                                        letterSpacing: .6
                                    )
                                    ),
                                    SizedBox(
                                      height: ScreenUtil.getInstance().setHeight(30),

                                    ),
                                    Text("Saisir Une ID  " , style: TextStyle(
                                      fontSize: ScreenUtil.getInstance().setSp(26),
                                      fontFamily: "Poppins-Meduim",)),
                                    TextField(
                                      obscureText: false
                                      ,
                                      decoration: InputDecoration (
                                          prefixIcon: Icon(Icons.person),
                                          hintText: " Ca sera Votre nouvelle ID",
                                          hintStyle: TextStyle(color: Colors.grey,
                                            fontSize: 12 ,)),

                                    ),
                                    SizedBox(
                                      height: ScreenUtil.getInstance().setHeight(30),

                                    ),
                                    Text("Mot de Passe" , style: TextStyle(
                                      fontSize: ScreenUtil.getInstance().setSp(26),
                                      fontFamily: "Poppins-Meduim",)),
                                    TextField(
                                      obscureText: true
                                      ,
                                      decoration: InputDecoration (
                                          prefixIcon: Icon(Icons.vpn_key),
                                          hintText: "Saisir votre Mot de passe ",
                                          hintStyle: TextStyle(color: Colors.grey,
                                            fontSize: 12 ,)),
                                    ),
                                    SizedBox(
                                      height: ScreenUtil.getInstance().setHeight(30),

                                    ),
                                    Text("Email" , style: TextStyle(
                                      fontSize: ScreenUtil.getInstance().setSp(26),
                                      fontFamily: "Poppins-Meduim",)),
                                    TextField(
                                      obscureText: false
                                      ,
                                      decoration: InputDecoration (
                                          prefixIcon: Icon(Icons.email),

                                          hintText: "Saisir votre Adresse Email ",
                                          hintStyle: TextStyle(color: Colors.grey,
                                            fontSize: 12 ,))
                                      ,),

                                    SizedBox(
                                      height: ScreenUtil.getInstance().setHeight(30),

                                    ),
                                    Text("Numéro de Telephone " , style: TextStyle(
                                      fontSize: ScreenUtil.getInstance().setSp(26),
                                      fontFamily: "Poppins-Meduim",)),
                                    TextField(
                                      obscureText:  false,
                                      decoration: InputDecoration (
                                          prefixIcon: Icon(Icons.phone),
                                          hintText: "Saisir Numero de Telephone ",
                                          hintStyle: TextStyle(color: Colors.grey,
                                            fontSize: 12 ,))
                                      ,),



                                  ],
                                ),


                              ),
















                            ), //this is what i want
                            SizedBox (
                              height: ScreenUtil.getInstance().setHeight(40),

                            ),
                            Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children:<Widget> [
                                  Row(

                                      children: <Widget>[
                                        SizedBox(
                                          width: 12.0,
                                        ),
                                      ]
                                  ),
                                  InkWell(
                                      child: Container(

                                          width: ScreenUtil.getInstance().setWidth(380),
                                          height: ScreenUtil.getInstance().setHeight(100),
                                          decoration: BoxDecoration(
                                              gradient: LinearGradient(
                                                  colors: [
                                                    Color(0xF818181),
                                                    Color(0XFF6078ea),
                                                  ]
                                              ),
                                              borderRadius: BorderRadius.circular(6.0),
                                              boxShadow: [
                                                BoxShadow(
                                                    color: Color(0XFF6078ea).withOpacity(.3),
                                                    offset: Offset(10.0,10.0),
                                                    blurRadius:8.0


                                                )

                                              ]
                                          ),
                                          child: Material(
                                            color: Colors.transparent,
                                            child: InkWell(
                                              onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext) => new MyApp())),
                                              child: Center ( child: Text("Valider ",style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18,
                                                  fontFamily: "Poppins-Bold",

                                                  letterSpacing: 1.0 ),

                                              )
                                              ),
                                            ),
                                          )
                                      )
                                  )
                                ]
                            )
                          ]
                      )
                  )
              )
            ]
        )
    );
  }
}